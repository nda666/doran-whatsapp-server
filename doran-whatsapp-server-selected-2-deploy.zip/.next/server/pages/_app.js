/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ \"antd\");\n/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next-i18next */ \"next-i18next\");\n/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! nextjs-progressbar */ \"nextjs-progressbar\");\n/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);\n\n\n\n\n\n\n\nconst App = ({ Component , pageProps: { session , ...pageProps }  })=>{\n    const getLayout = Component.getLayout || ((page)=>page);\n    const [lang, setLang] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(undefined);\n    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{\n        next_i18next__WEBPACK_IMPORTED_MODULE_4__.i18n?.language?.toString() == \"id\" ? Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! antd/locale/id_ID */ \"antd/locale/id_ID\", 23)).then((m)=>setLang(m.default)) : Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! antd/locale/en_US */ \"antd/locale/en_US\", 23)).then((m)=>setLang(m.default));\n    }, [\n        next_i18next__WEBPACK_IMPORTED_MODULE_4__.i18n?.language\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_3__.SessionProvider, {\n        session: session,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5___default()), {}, void 0, false, {\n                fileName: \"C:\\\\xampp\\\\htdocs\\\\doran-whatsapp-server\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__.ConfigProvider, {\n                locale: lang,\n                children: getLayout(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"C:\\\\xampp\\\\htdocs\\\\doran-whatsapp-server\\\\src\\\\pages\\\\_app.tsx\",\n                    lineNumber: 40,\n                    columnNumber: 20\n                }, undefined))\n            }, void 0, false, {\n                fileName: \"C:\\\\xampp\\\\htdocs\\\\doran-whatsapp-server\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\xampp\\\\htdocs\\\\doran-whatsapp-server\\\\src\\\\pages\\\\_app.tsx\",\n        lineNumber: 37,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.appWithTranslation)(App));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE4QjtBQUNRO0FBRVk7QUFDTTtBQUVUO0FBT2hDO0FBV2YsTUFBTU8sTUFBTSxDQUFDLEVBQ1hDLFVBQVMsRUFDVEMsV0FBVyxFQUFFQyxRQUFPLEVBQUUsR0FBR0QsV0FBVyxHQUNqQixHQUFLO0lBQ3hCLE1BQU1FLFlBQVlILFVBQVVHLFNBQVMsSUFBSyxFQUFDQyxPQUFTQSxJQUFHO0lBQ3ZELE1BQU0sQ0FBQ0MsTUFBTUMsUUFBUSxHQUFHUiwrQ0FBUUEsQ0FBcUJTO0lBQ3JEVixnREFBU0EsQ0FBQyxJQUFNO1FBQ2RGLDhDQUFJQSxFQUFFYSxVQUFVQyxjQUFjLE9BQzFCLHdJQUEyQixDQUFDQyxJQUFJLENBQUMsQ0FBQ0MsSUFBTUwsUUFBUUssRUFBRUMsT0FBTyxLQUN6RCx3SUFBMkIsQ0FBQ0YsSUFBSSxDQUFDLENBQUNDLElBQU1MLFFBQVFLLEVBQUVDLE9BQU8sRUFBRTtJQUNqRSxHQUFHO1FBQUNqQiw4Q0FBSUEsRUFBRWE7S0FBUztJQUNuQixxQkFDRSw4REFBQ2YsNERBQWVBO1FBQUNTLFNBQVNBOzswQkFDeEIsOERBQUNOLDJEQUFhQTs7Ozs7MEJBQ2QsOERBQUNKLGdEQUFjQTtnQkFBQ3FCLFFBQVFSOzBCQUNyQkYsd0JBQVUsOERBQUNIO29CQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSTNDO0FBRUEsaUVBQWVQLGdFQUFrQkEsQ0FBQ0ssSUFBQUEsRUFBMEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9kb3Jhbi13aGF0c2FwcC1zZXJ2ZXIvLi9zcmMvcGFnZXMvX2FwcC50c3g/ZjlkNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCJAL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xyXG5pbXBvcnQgeyBDb25maWdQcm92aWRlciB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IE5leHRQYWdlIH0gZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IHsgU2Vzc2lvblByb3ZpZGVyIH0gZnJvbSBcIm5leHQtYXV0aC9yZWFjdFwiO1xyXG5pbXBvcnQgeyBhcHBXaXRoVHJhbnNsYXRpb24sIGkxOG4gfSBmcm9tIFwibmV4dC1pMThuZXh0XCI7XHJcbmltcG9ydCB0eXBlIHsgQXBwUHJvcHMgfSBmcm9tIFwibmV4dC9hcHBcIjtcclxuaW1wb3J0IE5leHROUHJvZ3Jlc3MgZnJvbSBcIm5leHRqcy1wcm9ncmVzc2JhclwiO1xyXG5pbXBvcnQge1xyXG4gIENvbXBvbmVudFR5cGUsXHJcbiAgUmVhY3RFbGVtZW50LFxyXG4gIFJlYWN0Tm9kZSxcclxuICB1c2VFZmZlY3QsXHJcbiAgdXNlU3RhdGUsXHJcbn0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExvY2FsZSB9IGZyb20gXCJhbnRkL2xpYi9sb2NhbGVcIjtcclxuXHJcbmV4cG9ydCB0eXBlIE5leHRQYWdlV2l0aExheW91dDxQID0ge30sIElQID0gUD4gPSBOZXh0UGFnZTxQLCBJUD4gJiB7XHJcbiAgZ2V0TGF5b3V0PzogKHBhZ2U6IFJlYWN0RWxlbWVudCkgPT4gUmVhY3ROb2RlO1xyXG59O1xyXG5cclxudHlwZSBBcHBQcm9wc1dpdGhMYXlvdXQgPSBBcHBQcm9wcyAmIHtcclxuICBDb21wb25lbnQ6IE5leHRQYWdlV2l0aExheW91dDtcclxufTtcclxuXHJcbmNvbnN0IEFwcCA9ICh7XHJcbiAgQ29tcG9uZW50LFxyXG4gIHBhZ2VQcm9wczogeyBzZXNzaW9uLCAuLi5wYWdlUHJvcHMgfSxcclxufTogQXBwUHJvcHNXaXRoTGF5b3V0KSA9PiB7XHJcbiAgY29uc3QgZ2V0TGF5b3V0ID0gQ29tcG9uZW50LmdldExheW91dCB8fCAoKHBhZ2UpID0+IHBhZ2UpO1xyXG4gIGNvbnN0IFtsYW5nLCBzZXRMYW5nXSA9IHVzZVN0YXRlPExvY2FsZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaTE4bj8ubGFuZ3VhZ2U/LnRvU3RyaW5nKCkgPT0gXCJpZFwiXHJcbiAgICAgID8gaW1wb3J0KFwiYW50ZC9sb2NhbGUvaWRfSURcIikudGhlbigobSkgPT4gc2V0TGFuZyhtLmRlZmF1bHQpKVxyXG4gICAgICA6IGltcG9ydChcImFudGQvbG9jYWxlL2VuX1VTXCIpLnRoZW4oKG0pID0+IHNldExhbmcobS5kZWZhdWx0KSk7XHJcbiAgfSwgW2kxOG4/Lmxhbmd1YWdlXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxTZXNzaW9uUHJvdmlkZXIgc2Vzc2lvbj17c2Vzc2lvbn0+XHJcbiAgICAgIDxOZXh0TlByb2dyZXNzIC8+XHJcbiAgICAgIDxDb25maWdQcm92aWRlciBsb2NhbGU9e2xhbmd9PlxyXG4gICAgICAgIHtnZXRMYXlvdXQoPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPil9XHJcbiAgICAgIDwvQ29uZmlnUHJvdmlkZXI+XHJcbiAgICA8L1Nlc3Npb25Qcm92aWRlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXBwV2l0aFRyYW5zbGF0aW9uKEFwcCBhcyBDb21wb25lbnRUeXBlPEFwcFByb3BzV2l0aExheW91dD4pO1xyXG4iXSwibmFtZXMiOlsiQ29uZmlnUHJvdmlkZXIiLCJTZXNzaW9uUHJvdmlkZXIiLCJhcHBXaXRoVHJhbnNsYXRpb24iLCJpMThuIiwiTmV4dE5Qcm9ncmVzcyIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwic2Vzc2lvbiIsImdldExheW91dCIsInBhZ2UiLCJsYW5nIiwic2V0TGFuZyIsInVuZGVmaW5lZCIsImxhbmd1YWdlIiwidG9TdHJpbmciLCJ0aGVuIiwibSIsImRlZmF1bHQiLCJsb2NhbGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ "antd/locale/en_US":
/*!************************************!*\
  !*** external "antd/locale/en_US" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("antd/locale/en_US");

/***/ }),

/***/ "antd/locale/id_ID":
/*!************************************!*\
  !*** external "antd/locale/id_ID" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("antd/locale/id_ID");

/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ "next-i18next":
/*!*******************************!*\
  !*** external "next-i18next" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ "nextjs-progressbar":
/*!*************************************!*\
  !*** external "nextjs-progressbar" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();