export const WaSockQrTimeout =
  parseInt(process.env.WHATSAPP_QRTIMEOUT || "30") * 1000;
