import { useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";
import axios from "axios";
import { Phone } from "@prisma/client";

export default function useWhatsappBot() {}
