import * as socketio from "socket.io";
export const getSocketIO = new socketio.Server();
