-- AlterTable
ALTER TABLE `phones` ADD COLUMN `qrCode` TEXT NULL;
