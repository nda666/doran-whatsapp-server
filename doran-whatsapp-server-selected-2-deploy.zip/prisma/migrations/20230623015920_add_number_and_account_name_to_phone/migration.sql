-- AlterTable
ALTER TABLE `phones` ADD COLUMN `account_name` VARCHAR(191) NULL,
    ADD COLUMN `number` VARCHAR(191) NULL;
