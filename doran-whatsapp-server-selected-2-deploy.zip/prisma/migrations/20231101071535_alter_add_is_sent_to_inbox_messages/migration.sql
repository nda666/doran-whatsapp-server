-- AlterTable
ALTER TABLE `inbox_messages` ADD COLUMN `is_sent` BOOLEAN NOT NULL DEFAULT true;
